var cash = 0
var price1 = 30
var size = 3





//for (var i = 0; i < Infinity; i++) {
 
 
  
  
//

function myFunction() {
  
  cash = cash + 1
  
  document.getElementById("score").innerHTML = "$"+cash;
  
  
  
 
document.getElementById("score").style.fontSize = size +'rem';
  
}

//window.onload = var1;